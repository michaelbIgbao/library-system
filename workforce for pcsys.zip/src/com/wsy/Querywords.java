package com.wsy;
import java.awt.event.*;
import javax.swing.*;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.border.StandardBorderPainter;
import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.painter.StandardGradientPainter;
import org.jvnet.substance.skin.SubstanceBusinessBlackSteelLookAndFeel;
import org.jvnet.substance.theme.SubstanceAquaTheme;
import org.jvnet.substance.title.FlatTitlePainter;
import org.jvnet.substance.watermark.SubstanceBinaryWatermark;

import java.awt.*;
import java.awt.Container;
import java.util.*;
import java.sql.*;
public class Querywords implements ActionListener{
	JFrame f3;
	Container cp;
	JPanel jp1,jp2,jp3,jp4,jp,jpanelWest;
	JButton  jbt1,jbt2;//��ť��ȷ����ȡ��
	JLabel label;    //��ǩ�������뵥��
	JTextField tf,tf1,tf2,tf3,tf4,tf5,tf6;    //�����ı���
	JLabel label1,label2,label3,label4;
	Querywords()
	{
		f3=new JFrame();
		cp=f3.getContentPane(); // ��ʼ����塢��ť����ǩ���ı���
		jp1=new JPanel();
		jp2=new JPanel();
		jp3=new JPanel();
		jp4=new JPanel();
		jpanelWest=new JPanel();
		jp=new JPanel();
		jbt1=new JButton("confirm");
		jbt2=new JButton("cancel");
		label=new JLabel("<html><font color=#CC00FF size='4'>BookID</font>",SwingConstants.CENTER);
		label.setForeground(Color.blue);
		tf=new JTextField(20);
		tf1=new JTextField(20);
		tf2=new JTextField(20);
		tf3=new JTextField(20);
		tf4=new JTextField(20);
		tf5=new JTextField(20);
		tf6=new JTextField(20);
		JPanel jpanel=new JPanel();
		jpanel.add(label);
		jpanel.add(tf);
		JPanel pp4=new JPanel();
		JPanel jpane4=new JPanel();
		cp.add(jpanel,"North");
		JPanel pp2=new JPanel(new GridLayout(6,1));
		JPanel pp3=new JPanel();
		pp4.setLayout(new GridLayout(6,1));
		pp4.add(new JLabel("BookID",SwingConstants.CENTER));
		pp2.add(tf1);
		pp4.add(new JLabel("bookname",SwingConstants.CENTER));
		pp2.add(tf2);
		pp4.add(new JLabel("authorname",SwingConstants.CENTER));
		pp2.add(tf3);
		pp4.add(new JLabel("borrowstate",SwingConstants.CENTER));
		pp2.add(tf4);
		pp3.add(jbt1);
		pp3.add(jbt2);
		cp.add(pp4,"West");
		cp.add(pp2,"Center");
		cp.add(pp3,"South");
		cp.add(jpane4,"East");
		Toolkit kit=Toolkit.getDefaultToolkit();
		Dimension screen=kit.getScreenSize();
		int x=screen.width;     /*ȡ����ʾ�����ڵĿ��*/
		int y=screen.height;     /*ȡ����ʾ�����ڵĸ߶�*/
		f3.setSize(350,330);
		int xcenter=(x-350)/2;
		int ycenter=(y-330)/2;
		f3.setLocation(xcenter,ycenter);/*��ʾ�ڴ�������*/
		f3.setVisible(true);
		jbt1.addActionListener(this);//ע�������
		jbt2.addActionListener(this);
		/*f3.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(0);
				}
			}

				);*/
	}
	public void showRecord()
	{
		try{
			//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Class.forName("com.mysql.jdbc.Driver");
			}catch(ClassNotFoundException e){System.out.println("Oops something went wrong!");}
		try{
			//String url = "jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=Book.mdb";//ֱ��ʹ�õ�ǰ��Ŀ¼�µ����ݿ��ļ�
			java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?user=root&password=123456");
			java.sql.Statement sql;
			//Connection conn=DriverManager.getConnection(url);
			//Statement sql;
			String ql=tf.getText().trim();
			String ql1=tf.getText().trim();
			String ql2=tf.getText().trim();
			String s="select * from book where BID ='"+ql +"'";
			sql=conn.createStatement();
			ResultSet rs=sql.executeQuery(s);
			if(rs.next())
			{
				String BID=rs.getString(1);
				String bookname=rs.getString(2);
				String authorname=rs.getString(3);
				String borrowstate=rs.getString(4);
				tf1.setText(BID);
				tf2.setText(bookname);
				tf3.setText(authorname);
				tf4.setText(borrowstate);
			}
			else
			{JOptionPane.showMessageDialog(null,"Oops","something went wrong！", JOptionPane.YES_NO_OPTION);
			}
			conn.close();
		}catch(SQLException g)
		{
			System.out.println("E Code"+g.getErrorCode());
			System.out.println("E M"+g.getMessage());
			}
		tf1.setEditable(false);
		tf2.setEditable(false);
		tf3.setEditable(false);
		tf4.setEditable(false);
	}
	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e)
	{
		String cmd=e.getActionCommand();
		if(cmd.equals("confirm"))
		{
			showRecord();
			tf.setText("");
			}
		 else if(cmd.equals("cancel"))
			 f3.hide();
	}
	public static void main(String []arg){
		Querywords a=new Querywords();
		try {  
            //设置外观  
            UIManager.setLookAndFeel(new SubstanceBusinessBlackSteelLookAndFeel());  
            JFrame.setDefaultLookAndFeelDecorated(true);  
            //设置主题   
            SubstanceLookAndFeel.setCurrentTheme(new SubstanceAquaTheme());  
            //设置按钮外观  
            SubstanceLookAndFeel.setCurrentButtonShaper(new ClassicButtonShaper());  
            //设置水印  
            SubstanceLookAndFeel.setCurrentWatermark(new SubstanceBinaryWatermark());  
            //设置边框  
            SubstanceLookAndFeel.setCurrentBorderPainter(new StandardBorderPainter());  
            //设置渐变渲染  
            SubstanceLookAndFeel.setCurrentGradientPainter(new StandardGradientPainter());  
            //设置标题  
            SubstanceLookAndFeel.setCurrentTitlePainter(new FlatTitlePainter()); 
            JFrame.setDefaultLookAndFeelDecorated(true);

            JDialog.setDefaultLookAndFeelDecorated(true);
        } catch (Exception e) {  
            System.out.println(e.getMessage());  
        }
	}
}
