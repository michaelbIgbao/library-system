package com.wsy;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class backup
{
  public static void main(String[] args)
  {
   try
   {
      Process proc=Runtime.getRuntime().exec("cmd /mysqldump �Cuser=root �Cpassword=123456 �Clock-all-tables zuoye > E:\\abc.sql");
      System.out.println("successfully!");
      JOptionPane.showInputDialog("data back up successfully");
    }
   catch(Exception e)
   {}
   }
}