package com.wsy;
import java.awt.event.*;
import javax.swing.*;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.border.StandardBorderPainter;
import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.painter.StandardGradientPainter;
import org.jvnet.substance.skin.SubstanceBusinessBlackSteelLookAndFeel;
import org.jvnet.substance.theme.SubstanceAquaTheme;
import org.jvnet.substance.theme.SubstanceEbonyTheme;
import org.jvnet.substance.title.FlatTitlePainter;
import org.jvnet.substance.watermark.SubstanceBinaryWatermark;

import java.awt.*;
import java.awt.Container;
import java.util.*;
import java.sql.*;
public class bookBrower implements  ActionListener{
	JFrame f;
	Container cp;
	JPanel jpS,jpanelWest;
	JButton  jbt1,jbt2;
	JLabel label,L;   
	JTable table;
	Object columnName[]={"bookID","bookname","authorname"};
	Object ar[][] =new Object[80][12];
	String sno;
	String count=" ";
	bookBrower()
	{
		f=new JFrame();
		cp=f.getContentPane();
		jpS=new JPanel();
		jpanelWest=new JPanel();
		jbt1=new JButton("confirm");
		jbt2=new JButton("cancel");
		label=new JLabel("<html><font color=#7F00FF size='4'>bookbrowser</font>",SwingConstants.CENTER);
		label.setForeground(Color.blue);
		L=new JLabel("Library has "+count+" books ");
		table=new JTable(ar,columnName);
		JScrollPane scrollpane = new JScrollPane(table);
		//����,��ӿؼ�
		jpS.add(jbt1);
		jpS.add(jbt2);
		JPanel jpanel=new JPanel();
		jpanel.add(label);
		JPanel pp4=new JPanel();
		JPanel jpE=new JPanel();
		cp.add(jpanel,"North");
		JPanel jp=new JPanel();
		//jp.add(scrollpane);
		JPanel p=new JPanel();//������������
		p.setLayout(new BorderLayout());
		p.add(L,"North");
		p.add(scrollpane);
		cp.add(pp4,"West");
		cp.add(p,"Center");
		cp.add(jpS,"South");
		cp.add(jpE,"East");
		Toolkit kit=Toolkit.getDefaultToolkit();
		Dimension screen=kit.getScreenSize();
		int x=screen.width;     /*ȡ����ʾ�����ڵĿ��*/
		int y=screen.height;     /*ȡ����ʾ�����ڵĸ߶�*/
		f.setSize(400,330);
		int xcenter=(x-350)/2;
		int ycenter=(y-330)/2;
		f.setLocation(xcenter,ycenter);/*��ʾ�ڴ�������*/
		f.setVisible(true);
		jbt1.addActionListener(this);//ע�������
		jbt2.addActionListener(this);
	}
	int i=0;
	public void showRecord()
	{
		while(i>=0)
		{
			ar[i][0]="";
			ar[i][1]="";
			ar[i][2]="";
			ar[i][3]="";
			ar[i][4]="";
			ar[i][5]="";
			ar[i][6]="";
			ar[i][7]="";
			ar[i][8]="";
			ar[i][9]="";
			ar[i][10]="";
			ar[i][11]="";
			i--;
			}
		i=0;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			}catch(ClassNotFoundException e){System.out.println("Oops something went wrong!");}
		try{
			java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?user=root&password=123456");
			java.sql.Statement sql;
			sql=conn.createStatement();
			//Connection conn=DriverManager.getConnection(url);
			String s="select * from book ";

			ResultSet rs=sql.executeQuery(s);
		
		  while(rs.next())
			{
				String bookID=rs.getString(1);
				String bookname=rs.getString(2);
				String authorname=rs.getString(3);
				String bookstate=rs.getString(4);
				ar[i][0]=bookID;
				ar[i][1]=bookname;
				ar[i][2]=authorname;
				ar[i][3]=bookstate;
	
				i++;
			}
			count=""+i+"";
			L.setText("Library has "+count+" books");
			f.repaint();
			conn.close();
		}catch(SQLException g)
		{
			System.out.println("E Code"+g.getErrorCode());
			System.out.println("E M"+g.getMessage());
			}
	}
	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e)
	{
		String cmd=e.getActionCommand();
		if(cmd.equals("confirm"))
		{
			f.hide();
			}
		if(cmd.equals("cancel"))
			f.hide();
	}
	public static void main(String []arg){
		bookBrower a=new bookBrower();
		a.showRecord();
		 try {  
	            //设置外观  
	            UIManager.setLookAndFeel(new SubstanceBusinessBlackSteelLookAndFeel());  
	            JFrame.setDefaultLookAndFeelDecorated(true);  
	            //设置主题   
	            SubstanceLookAndFeel.setCurrentTheme(new SubstanceAquaTheme());  
	            //设置按钮外观  
	            SubstanceLookAndFeel.setCurrentButtonShaper(new ClassicButtonShaper());  
	            //设置水印  
	            SubstanceLookAndFeel.setCurrentWatermark(new SubstanceBinaryWatermark());  
	            //设置边框  
	            SubstanceLookAndFeel.setCurrentBorderPainter(new StandardBorderPainter());  
	            //设置渐变渲染  
	            SubstanceLookAndFeel.setCurrentGradientPainter(new StandardGradientPainter());  
	            //设置标题  
	            SubstanceLookAndFeel.setCurrentTitlePainter(new FlatTitlePainter());  
	            JFrame.setDefaultLookAndFeelDecorated(true);

	            JDialog.setDefaultLookAndFeelDecorated(true);
	        } catch (Exception e) {  
	            System.out.println(e.getMessage());  
	        }
	}
}
