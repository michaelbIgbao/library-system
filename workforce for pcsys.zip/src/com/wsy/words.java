package com.wsy;

import java.net.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.border.StandardBorderPainter;
import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.painter.StandardGradientPainter;
import org.jvnet.substance.skin.SubstanceBusinessBlackSteelLookAndFeel;
import org.jvnet.substance.theme.SubstanceAquaTheme;
import org.jvnet.substance.theme.SubstanceEbonyTheme;
import org.jvnet.substance.title.FlatTitlePainter;
import org.jvnet.substance.watermark.SubstanceBinaryWatermark;

import java.util.*;

public class words extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton QueryScore = new JButton("add book");
	JButton jiangfa = new JButton("remove book");
	JButton chaxun = new JButton("enquiry book");
	JButton gaikuang = new JButton("bookBrowser");
	JButton funnygame = new JButton("funny game");
	JButton gaimima = new JButton("change password");
	JButton backup = new JButton("back up data");
	JButton btn = new JButton();
	JMenuBar mb = new JMenuBar();// �˵���
	JPanel jp = new JPanel();// ���������ģ��
	JPanel jp2 = new JPanel();
	Container cp = getContentPane();
	String username;

	words() {
	}

	words(String username) {
		
		JLabel l = new JLabel();
		Icon icon = new ImageIcon("C:\\Users\\michael-bao\\Desktop\\1.JPG"); // �ڴ�ֱ�Ӵ�������
		l.setIcon(icon);
		jp2.add(l);
		this.username = username;
		mb.add(QueryScore);
		mb.add(chaxun);
		mb.add(jiangfa);
		mb.add(funnygame);
		mb.add(gaimima);
		mb.add(backup);
		mb.add(gaikuang);
		cp.add(mb, "North");
		jp.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.blue, 2), null,
				TitledBorder.CENTER, TitledBorder.TOP));
		jp.setLayout(new BorderLayout());
		JLabel label1 = new JLabel(new ImageIcon("C:\\Users\\michael-bao\\Desktop\\1.jpg"));
		label1.setBorder(null);
		jp.add(label1);
		JScrollPane scrollpane = new JScrollPane(jp);
		cp.add(scrollpane);
		setTitle("main menu");
		Toolkit kit = Toolkit.getDefaultToolkit();
		setLocation(600, 500);
		Dimension screen = kit.getScreenSize();
		int x = screen.width; /* ȡ����ʾ�����ڵĿ�� */
		int y = screen.height; /* ȡ����ʾ�����ڵĸ߶� */
		// setSize(x,y); /*��ϵͳ����ƽ��������ʾ������*/
		setSize(575, 500);
		int xcenter = (x - 618) / 2;
		int ycenter = (y - 600) / 2;
		setLocation(xcenter, ycenter);/* ��ʾ�ڴ������� */
		setVisible(true);
		cp.setVisible(true);
		// f3.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// ע��������
		QueryScore.addActionListener(this);
		chaxun.addActionListener(this);
		jiangfa.addActionListener(this);
		funnygame.addActionListener(this);
		gaimima.addActionListener(this);
		gaikuang.addActionListener(this);
		backup.addActionListener(this);
		//backup.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if (cmd.equals("add book")) {
			new BookIn();
		}
		if (cmd.equals("remove book")) {
			new Removebooks();
		}
		if (cmd.equals("enquiry book")) {
			new Querywords();
		}
		if (cmd.equals("funny game")) {

			SnakeModel model = new SnakeModel(20, 30);
			SnakeControl control = new SnakeControl(model);
			SnakeView view = new SnakeView(model, control);
			// 添加一个观察者，让view成为model的观察者
			model.addObserver(view);

			(new Thread(model)).start();

		}
		if (cmd.equals("bookBrower")) {
			bookBrower a=new bookBrower();
			a.showRecord();
		}
		if (cmd.equals("change password")) {
			new UpdateMima(username);
		}
		if (cmd.equals("backup data")) {
			new backup();
		}

	}

	public static void main(String[] args) {
		new words("");
		 try {  
	            //设置外观  
	            UIManager.setLookAndFeel(new SubstanceBusinessBlackSteelLookAndFeel());  
	            JFrame.setDefaultLookAndFeelDecorated(true);  
	            //设置主题   
	            SubstanceLookAndFeel.setCurrentTheme(new SubstanceAquaTheme());  
	            //设置按钮外观  
	            SubstanceLookAndFeel.setCurrentButtonShaper(new ClassicButtonShaper());  
	            //设置水印  
	            SubstanceLookAndFeel.setCurrentWatermark(new SubstanceBinaryWatermark());  
	            //设置边框  
	            SubstanceLookAndFeel.setCurrentBorderPainter(new StandardBorderPainter());  
	            //设置渐变渲染  
	            SubstanceLookAndFeel.setCurrentGradientPainter(new StandardGradientPainter());  
	            //设置标题  
	            SubstanceLookAndFeel.setCurrentTitlePainter(new FlatTitlePainter()); 
	            JFrame.setDefaultLookAndFeelDecorated(true);

	            JDialog.setDefaultLookAndFeelDecorated(true);
	        } catch (Exception e) {  
	            System.out.println(e.getMessage());  
	        }
}
}