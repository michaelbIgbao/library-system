package com.wsy;
import java.awt.event.*; 
import javax.swing.*; 
import java.util.*;
import javax.swing.text.JTextComponent;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.border.StandardBorderPainter;
import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.painter.StandardGradientPainter;
import org.jvnet.substance.skin.SubstanceBusinessBlackSteelLookAndFeel;
import org.jvnet.substance.theme.SubstanceAquaTheme;
import org.jvnet.substance.title.FlatTitlePainter;
import org.jvnet.substance.watermark.SubstanceBinaryWatermark;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import com.mysql.jdbc.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.awt.*;
import java.util.*; 
import java.sql.*;
class Login extends JFrame  implements  ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Container cp=null;    
	JFrame f=null; 
	JFrame f2=null; 
	JButton j1,j2;    
	JTextField t1;    
	JPasswordField t2;     
	JLabel jlable1,jlable2;     
	Color c;     
	JPanel jp1,jp2;
	Login(){        
		f=new JFrame(" welcom to login ");   
		j1=new JButton("confirm");   
		j2=new JButton("cancel");   
		cp=f.getContentPane();    
		jlable1=new JLabel("username");   
		jlable2=new JLabel("password");
		jp1=new JPanel();   
		jp2=new JPanel();    
		t1=new JTextField(18);   
		t2=new JPasswordField(18);             
		jp1.add(jlable1);         
		jp1.add(t1);          
		jp1.add(jlable2);   
		jp1.add(t2);          
		JLabel  JL=new JLabel("Pace library system",SwingConstants.CENTER);
		cp.add(JL,"North");
  
		jp2.add(j1);   
		jp2.add(j2);       
		cp.add(jp1,"Center");      
		cp.add("South",jp2); 
		jp1.setBackground(new Color(255, 255, 255));
		Toolkit kit=Toolkit.getDefaultToolkit();   
		Dimension screen=kit.getScreenSize();    
		int x=screen.width;    
		int y=screen.height;      
		
		f.setSize(300,300);         
		int xcenter=(x-300)/2;      
		int ycenter=(y-300)/2;       
		f.setLocation(xcenter,ycenter);         
		f.setVisible(true);
		j1.addActionListener(this);        
		j2.addActionListener(this);         
		f.addWindowListener(new WindowAdapter(){     
			public void windowClosing(WindowEvent e){     
				System.exit(0);    
				}   
			}   
		);  
		}
	
	@SuppressWarnings("deprecation")
	public void confirm() throws SQLException 
	{
		try{
			//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Class.forName("com.mysql.jdbc.Driver");	
			}catch(ClassNotFoundException e){System.out.println("oops there seems to be a problem!");}
		try{     
			java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?user=root&password=123456");
			java.sql.Statement sql;	   	   
		   // Statement sql1=sql.con.createStatement();   		
			String username=t1.getText().trim();
			String password=t2.getText().trim();     
			String queryMima="select * from login where username='"+username+"' and password='"+password+"'"; 
			sql=conn.createStatement();
			java.sql.ResultSet rs=sql.executeQuery(queryMima);             
			if(rs.next())
			{      
				new words(username);     
				f.hide();           
				conn.close();                   
			}else{      
				JOptionPane.showMessageDialog(null,"wrong password","something went wrong",JOptionPane.YES_NO_OPTION);             
				}
			t1.setText("");     
			t2.setText("");
	}catch(SQLException g)     
		{      
		System.out.println("E Code"+g.getErrorCode());     
		System.out.println("E M"+g.getMessage());         
		}
}

	 public void actionPerformed(ActionEvent e)        
	 {     
		 String cmd=e.getActionCommand();     
		 if(cmd.equals("confirm")){      
			 try {
				confirm();
				new words();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			 
			 }
		 else if(cmd.equals("cancel")){      
			 f.dispose();     
			 }
	 }
	 public static void main(String []arg){             
		 Login a=new Login(); 
		 try {  
	            //设置外观  
	            UIManager.setLookAndFeel(new SubstanceBusinessBlackSteelLookAndFeel());  
	            JFrame.setDefaultLookAndFeelDecorated(true);  
	            //设置主题   
	            SubstanceLookAndFeel.setCurrentTheme(new SubstanceAquaTheme());  
	            //设置按钮外观  
	            SubstanceLookAndFeel.setCurrentButtonShaper(new ClassicButtonShaper());  
	            //设置水印  
	            SubstanceLookAndFeel.setCurrentWatermark(new SubstanceBinaryWatermark());  
	            //设置边框  
	            SubstanceLookAndFeel.setCurrentBorderPainter(new StandardBorderPainter());  
	            //设置渐变渲染  
	            SubstanceLookAndFeel.setCurrentGradientPainter(new StandardGradientPainter());  
	            //设置标题  
	            SubstanceLookAndFeel.setCurrentTitlePainter(new FlatTitlePainter()); 
	            JFrame.setDefaultLookAndFeelDecorated(true);

	            JDialog.setDefaultLookAndFeelDecorated(true);
	        } catch (Exception e) {  
	            System.out.println(e.getMessage());  
	        }
		 }
}

