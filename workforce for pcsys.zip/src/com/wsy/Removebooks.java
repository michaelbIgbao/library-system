package com.wsy;
import java.awt.event.*; 
import javax.swing.*;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.border.StandardBorderPainter;
import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.painter.StandardGradientPainter;
import org.jvnet.substance.skin.SubstanceBusinessBlackSteelLookAndFeel;
import org.jvnet.substance.theme.SubstanceAquaTheme;
import org.jvnet.substance.title.FlatTitlePainter;
import org.jvnet.substance.watermark.SubstanceBinaryWatermark;

import java.awt.*;  
import java.awt.Container; 
import java.util.*; 
import java.sql.*;
public class Removebooks implements  ActionListener{
	JFrame f;  
	Container cp;   
	JPanel jpS,jpanelWest;   
	JButton  jbt1,jbt2,jbt3;//��ť����ѯ��ȡ�����޸� 
	JLabel label,L;    //��ǩ��������ѧ��  
	JTextField tf;    //�����ı���   
	JTable table;//�����������ݿ��з��ص���Ϣ      
	Object columnName[]={"BookID","authorname"};     
	Object ar[][] =new Object[80][2];  
	String bmeaning;   
	String count=" ";
	Removebooks()    
	{    
		f=new JFrame();   
		cp=f.getContentPane(); // ��ʼ����塢��ť����ǩ���ı���  
		jpS=new JPanel();            
		jpanelWest=new JPanel();
		jbt1=new JButton("enquiry");     
		jbt2=new JButton("delete");     
		jbt3=new JButton("cancel");
		label=new JLabel("<html><font color=#CC00FF size='4'>Bookname</font>",SwingConstants.CENTER);  
		label.setForeground(Color.red);   
		L=new JLabel("Our library have"+count+"this book");
		table=new JTable(ar,columnName);
		JScrollPane scrollpane = new JScrollPane(table);
		tf=new JTextField(18);
		jpS.add(jbt1);     
		jpS.add(jbt2);  
		jpS.add(jbt3);
		JPanel jpanel=new JPanel();  
		jpanel.add(label);  
		jpanel.add(tf);
		JPanel pp4=new JPanel();     
		JPanel jpE=new JPanel();     
		cp.add(jpanel,"North");  
		JPanel jp=new JPanel();  
		//jp.add(scrollpane);   
		JPanel p=new JPanel();//������������  
		p.setLayout(new BorderLayout());     
		p.add(L,"North");
		p.add(scrollpane);       
		cp.add(pp4,"West");  
		cp.add(p,"Center");     
		cp.add(jpS,"South");      
		cp.add(jpE,"East");
		Toolkit kit=Toolkit.getDefaultToolkit();  
		Dimension screen=kit.getScreenSize();   
		int x=screen.width;     /*ȡ����ʾ�����ڵĿ��*/  
		int y=screen.height;     /*ȡ����ʾ�����ڵĸ߶�*/  
		f.setSize(400,330);   
		int xcenter=(x-350)/2;   
		int ycenter=(y-330)/2;    
		f.setLocation(xcenter,ycenter);/*��ʾ�ڴ�������*/   
		f.setVisible(true);
		jbt1.addActionListener(this);//ע�������     
		jbt2.addActionListener(this);     
		jbt3.addActionListener(this);
		/*f.addWindowListener(new WindowAdapter(){     
			public void windowClosing(WindowEvent e){     
				System.exit(0);    
				}   
			}   
		);*/ 
	}
	int i=0;     
	public void showRecord(String ql)  
	{
		while(i>=0)    
		{      
			ar[i][0]="";    
			ar[i][1]="";        
			i--;    
			}
		i=0;            
		try{     
			Class.forName("com.mysql.jdbc.Driver");     
			}catch(ClassNotFoundException e){System.out.println("Oops something went wrong!");}
		try{      
			java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?user=root&password=123456");
			java.sql.Statement sql;     
			String s="select * from book where bookname ='"+ql +"'";               
			sql=conn.createStatement();       
			ResultSet rs=sql.executeQuery(s);
			while(rs.next())            
			{         
				String BID=rs.getString(1);     
				String authorname=rs.getString(3);     
  
                ar[i][0]=BID;     
                ar[i][1]=authorname;        
                i++;      
                } 
			count=""+i+"";           
			L.setText("Our library have "+count+" this book");           
			f.repaint();
			conn.close();System.out.println(ar[0][1]); 
		}catch(SQLException g)     
		{       
			System.out.println("E Code"+g.getErrorCode());      
			System.out.println("E M"+g.getMessage());
		}
	}
	public void deleteRecord(int index)  
	{                     
		try{     
			Class.forName("com.mysql.jdbc.Driver");       
			}catch(ClassNotFoundException e){System.out.println("Oops something went wrong!");}
		try{     
			java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?user=root&password=123456");
			java.sql.Statement sql;        
			String ql=(String)(ar[index][1]);     
			String s="delete from book where bookname = "+ql ;             
			sql=conn.createStatement();   
			int del=sql.executeUpdate(s);
			if(del==1)                
			{JOptionPane.showMessageDialog(null,"success", "book have been removed", JOptionPane.YES_NO_OPTION);      
			}       
			conn.close();
			f.repaint();
		}catch(SQLException g)     
		{      
			System.out.println("E Code"+g.getErrorCode());     
			System.out.println("E M"+g.getMessage());         
			} 
	}
	public void actionPerformed(ActionEvent e)  
	{      
		String remember="";   
		String ql="";     
		String cmd=e.getActionCommand(); 
		if(cmd.equals("enquiry"))            
		{              
			ql=tf.getText().trim();     
			remember=ql;        
			showRecord(ql);           
			} 
		if(cmd.equals("delete"))       
		{         
			int index=table.getSelectedRow();       
			if( index==-1)       
				JOptionPane.showMessageDialog(null,"Oops", "book do not exist", JOptionPane.YES_NO_OPTION);         
			else{         
				deleteRecord(index);          
			    //showRecord(remember);                 
			}
		}
			if(cmd.equals("cancel"))        
			f.hide();		
		}
		public static void main(String []arg){             
			Removebooks a=new Removebooks();
			try {  
	            //设置外观  
	            UIManager.setLookAndFeel(new SubstanceBusinessBlackSteelLookAndFeel());  
	            JFrame.setDefaultLookAndFeelDecorated(true);  
	            //设置主题   
	            SubstanceLookAndFeel.setCurrentTheme(new SubstanceAquaTheme());  
	            //设置按钮外观  
	            SubstanceLookAndFeel.setCurrentButtonShaper(new ClassicButtonShaper());  
	            //设置水印  
	            SubstanceLookAndFeel.setCurrentWatermark(new SubstanceBinaryWatermark());  
	            //设置边框  
	            SubstanceLookAndFeel.setCurrentBorderPainter(new StandardBorderPainter());  
	            //设置渐变渲染  
	            SubstanceLookAndFeel.setCurrentGradientPainter(new StandardGradientPainter());  
	            //设置标题  
	            SubstanceLookAndFeel.setCurrentTitlePainter(new FlatTitlePainter()); 
	            JFrame.setDefaultLookAndFeelDecorated(true);

	            JDialog.setDefaultLookAndFeelDecorated(true);
	        } catch (Exception e) {  
	            System.out.println(e.getMessage());  
	        }
	}
}
