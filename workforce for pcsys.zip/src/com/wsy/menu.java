package com.wsy;

import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;
import javax.swing.*;
 
public class menu extends JFrame implements ActionListener,ItemListener
{
    JTextField msg = new JTextField();
    JMenuBar mb = new JMenuBar();
    JMenu m1 = new JMenu("File");
    JMenu m2 = new JMenu("�����˵�");
    JMenuItem item = new JMenuItem("��ͨ�˵���");
    JCheckBoxMenuItem checkbox = new JCheckBoxMenuItem("��ѡ�˵���");
    JMenuItem exit = new JMenuItem("�˳�");
   
    public menu()
    {
        addWindowListener(new WindowAdapter()
        {
        public void windowClosing(WindowEvent e)
            {
            System.exit(0);
            }
        });
       
        Container c = getContentPane();
        setTitle("�˵��ۺ�Ӧ��");
        setSize(350,200);
        c.add(msg);
        mb.add(m1);
        m1.add(m2);
        checkbox.setState(true);
        m1.add(item);
        m1.setMnemonic('F');
        item.setAccelerator(KeyStroke.getKeyStroke('I',java.awt.Event.CTRL_MASK,false));
        m1.add(checkbox);
        m1.addSeparator();
        m1.add(exit);
        m2.add("�˵���A");
        m2.add("�˵���B");
        item.addActionListener(this);
        checkbox.addItemListener(this);
        exit.addActionListener(this);
        setJMenuBar(mb);
        show();
    }
   
    public void actionPerformed(ActionEvent e)
    {
       if (e.getSource()==exit)
           System.exit(0);
       else
           msg.setText(e.getActionCommand()+"����");
    }
   
    public void itemStateChanged(ItemEvent e)
    {
       if (e.getSource()==checkbox)
       {
           if (checkbox.getState())
              msg.setText(checkbox.getText()+"��ѡ��");
           else
              msg.setText(checkbox.getText()+"��ȡ��");
       }
    }
   
    public static void main(String[] args)
    {
       new menu();
    }
   
}