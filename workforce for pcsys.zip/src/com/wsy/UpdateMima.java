package com.wsy;
import java.net.*; 
import java.sql.*; 
import java.awt.*;  
import java.awt.event.*; 
import java.io.*; 
import java.util.*; 
import javax.swing.*;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.border.StandardBorderPainter;
import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.painter.StandardGradientPainter;
import org.jvnet.substance.skin.SubstanceBusinessBlackSteelLookAndFeel;
import org.jvnet.substance.theme.SubstanceAquaTheme;
import org.jvnet.substance.title.FlatTitlePainter;
import org.jvnet.substance.watermark.SubstanceBinaryWatermark;
public class UpdateMima extends JFrame implements ActionListener{
	JFrame f,f1;  
	Container cp;   
	JPanel jp1,jp2,jp3,jp4,jp,jpanelWest;  
	JButton  jbt1,jbt2;//��ť��ȷ����ȡ��  
	JLabel label;    //��ǩ���޸�����  
	JTextField name,tf1;      
	JPasswordField tf2,tf3;    //�����ı���  
	JLabel label1,label2,label3,label4;  
	String sno;  
	UpdateMima(){}
	UpdateMima(String username)    
	{   
		sno=username;  
		f=new JFrame();
		f1=new JFrame();  
		cp=f.getContentPane(); // ��ʼ�� 
		
		jp1=new JPanel();         
		jp2=new JPanel();  
		jp3=new JPanel();  
		jp4=new JPanel();   
		jpanelWest=new JPanel();  
		jp=new JPanel();
		jbt1=new JButton("confirm");     
		jbt2=new JButton("cancel");
		label=new JLabel("<html><font color=#CC00FF size='4'>change password</font>",SwingConstants.CENTER);  
		label.setForeground(Color.blue);   
		label.setFont(new Font("BOLD",Font.BOLD,15));  
		name=new JTextField(20);     
		//name.setEditable(false);
		tf1=new JTextField(20);  
		tf2=new JPasswordField(20);  
		tf3=new JPasswordField(20);
		jp1.add(jbt1);
		jp1.add(jbt2);     
		jp1.add(new JLabel(""));     
		JPanel jpanel=new JPanel();  
		jpanel.add(label);     
		JPanel pp4=new JPanel();     
		JPanel jpane4=new JPanel();
		cp.add(jpanel,"North");   
		JPanel pp2=new JPanel(new GridLayout(6,1));  
		JPanel pp3=new JPanel();   
		pp4.setLayout(new GridLayout(6,1));   
		pp4.add(new JLabel("username ",SwingConstants.RIGHT));  
		pp2.add(name);   
		pp4.add(new JLabel("confirm username",SwingConstants.RIGHT));
		pp2.add(tf1);   
		pp4.add(new JLabel("new password",SwingConstants.RIGHT));  
		pp2.add(tf2);    
		pp4.add(new JLabel("confirm password",SwingConstants.RIGHT));  
		pp2.add(tf3);   
		pp2.add(new JLabel());      
		JPanel jpbutton=new JPanel();  
		jpbutton.add(jbt1);  
		jpbutton.add(jbt2);  
		pp2.add(jpbutton);
		//pp3.add(jbt1);    
		//pp3.add(jbt2);       
		cp.add(pp4,"West");  
		cp.add(pp2,"Center");     
		//cp.add(pp3,"South");      
		cp.add(jpane4,"East");
		Toolkit kit=Toolkit.getDefaultToolkit();   
		Dimension screen=kit.getScreenSize();    
		int x=screen.width;     /*ȡ����ʾ�����ڵĿ��*/
		int y=screen.height;    
		f.setSize(350,330);     /*ȡ����ʾ�����ڵĸ߶�*/   
		int xcenter=(x-350)/2;   
		int ycenter=(y-330)/2;    
		f.setLocation(xcenter,ycenter);/*��ʾ�ڴ�������*/     
		f.setVisible(true);
		jbt1.addActionListener(this);//ע�������     
		jbt2.addActionListener(this);
		f.addWindowListener(new WindowAdapter(){     
			public void windowClosing(WindowEvent e){     
				System.exit(0);    
				}   
			}   
		);
	}
	public void updateM()  {           
		try{     
			Class.forName("com.mysql.jdbc.Driver");
			}catch(ClassNotFoundException e){System.out.println("something went wrong!");}
		try{     
			java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?user=root&password=123456");
			java.sql.Statement sql;
			sql=conn.createStatement();      
			String uname=name.getText().trim();     
			String queryMima="select * from login where username='"+uname+"'";    
			ResultSet rs=sql.executeQuery(queryMima);
			if(rs.next())    
			{                 
				String newMima=tf2.getText().trim();                  
				String s="update login set password='"+newMima+"' where username ='"+uname +"'";                  
				sql=conn.createStatement();         
				int updateMima=sql.executeUpdate(s);
				if(updateMima==1)               
				{
					JOptionPane.showMessageDialog(f,"suceess,update password"); 
				}
				conn.close();      
				f.repaint(); 
			}else{      
				JOptionPane.showMessageDialog(null,"sorry","your username is wrong",JOptionPane.YES_NO_OPTION);             
				}
			name.setText("");     
			tf1.setText("");     
			tf2.setText("");     
			tf3.setText("");
		}catch(SQLException g)     
		{      
			System.out.println("E Code"+g.getErrorCode());    
			System.out.println("E M"+g.getMessage());         
			} 
	}
	public void actionPerformed(ActionEvent e)  
	{    
		String cmd=e.getActionCommand();       
		if(cmd.equals("confirm"))     
		{
			if(name.getText().equals("")||tf1.getText().equals("")||tf2.getText().equals("")||tf3.getText().equals("")) 
			{                     
				JOptionPane.showMessageDialog(null,"����д�û���������Ϣ","��ʾ",JOptionPane.YES_NO_OPTION);              
				return;             
				}
			if(tf2.getText().trim().equals(tf3.getText().trim()))                       
				updateM();                  
			}
		else if(cmd.equals("cancel"))        
			f.hide(); 
	}
	public static void main(String[]args)   
	{     
		new UpdateMima("");   
		 UpdateMima a=new UpdateMima(); 
		 try {  
	            //设置外观  
	            UIManager.setLookAndFeel(new SubstanceBusinessBlackSteelLookAndFeel());  
	            JFrame.setDefaultLookAndFeelDecorated(true);  
	            //设置主题   
	            SubstanceLookAndFeel.setCurrentTheme(new SubstanceAquaTheme());  
	            //设置按钮外观  
	            SubstanceLookAndFeel.setCurrentButtonShaper(new ClassicButtonShaper());  
	            //设置水印  
	            SubstanceLookAndFeel.setCurrentWatermark(new SubstanceBinaryWatermark());  
	            //设置边框  
	            SubstanceLookAndFeel.setCurrentBorderPainter(new StandardBorderPainter());  
	            //设置渐变渲染  
	            SubstanceLookAndFeel.setCurrentGradientPainter(new StandardGradientPainter());  
	            //设置标题  
	            SubstanceLookAndFeel.setCurrentTitlePainter(new FlatTitlePainter()); 
	            JFrame.setDefaultLookAndFeelDecorated(true);

	            JDialog.setDefaultLookAndFeelDecorated(true);
	        } catch (Exception e) {  
	            System.out.println(e.getMessage());  
	        }
		}
}
